package com.example.http_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpTestApplication.class, args);
	}

}
